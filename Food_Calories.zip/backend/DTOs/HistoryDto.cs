﻿namespace FoodCalorie.DTOs
{
    public class HistoryDto
    {

        public string UserId { get; set; }
        public string MealName { get; set; }

        public float Calories { get; set; }

        public float Protein { get; set; }

        public float Carbs { get; set; }

        public float Fat { get; set; }
        public float Wieght { get; set; }

    }
}
